# JD Service Track — Multi-technician + manager system

## Initial company configuration
- App/company display name: JD Service Track
- Intended manager/admin email: jdservices736@gmail.com
- Initial technician capacity: 5 individual technician accounts

The manager account and technician accounts are **not created automatically** by this source bundle. Create them in Supabase Authentication, then add matching rows to `public.profiles` as described below.

This bundle contains the first full-system starter:
- Manager web dashboard (create/assign orders, view team and job status)
- Android-first technician web app (login, assigned jobs, checklist, start/finish, map handoff)
- Supabase schema for authentication, shared cloud data, and row-level security
- Capacitor Android project configuration

## 1. Create the cloud backend
1. Create a project at https://supabase.com/.
2. Open SQL Editor and run `supabase/schema.sql`.
3. In Project Settings → API, copy the Project URL and anon/public key.
4. Paste both into `web/config.js`. Never use the `service_role` key in the app.

## 2. Create the first manager account
Create the manager user in Supabase Authentication using `jdservices736@gmail.com` as the email. Set the password privately in Supabase; do not share it in chat. Then follow the UUID/profile steps below.

1. In Supabase → Authentication → Users, add the manager's email/password.
2. Copy that user's UUID.
3. In SQL Editor run:
   `insert into public.profiles (id, full_name, role) values ('USER-UUID', 'Manager Name', 'manager');`
4. Add your five technicians (each with their own email and password) in Authentication → Users and insert matching profile rows with role `technician`:
   `insert into public.profiles (id, full_name, role) values ('TECH-UUID', 'Technician Name', 'technician');`
5. Create technician users with unique email/passwords and distribute credentials securely.

## 3. Run the manager dashboard locally
Requires Node.js 20+.
- `npm install`
- `npm run serve`
- Open `http://localhost:4173` for manager portal.
- Open `http://localhost:4173/technician.html` for technician portal.

For phones and real-world use, host the `web/` folder on HTTPS. Configure Supabase Auth redirect/site URLs to match your hosted domain.

## 4. Build Android APK
Requires Android Studio + Android SDK + JDK 17+.
- `npm install`
- `npx cap add android`
- `npx cap sync android`
- `npx cap open android`
In Android Studio select Build → Build Bundle(s) / APK(s) → Build APK(s).
The debug APK is normally at `android/app/build/outputs/apk/debug/app-debug.apk`.
For distribution, configure a signing key and build a signed release APK/AAB.

## Security and production notes
- Supabase Auth handles login; RLS limits technicians to their own assigned jobs.
- Manager role can read/manage team and jobs.
- Do not expose service-role credentials in browser or APK.
- This starter does not yet include background GPS tracking, push notifications, route optimization, photo uploads, signatures, offline write queue, audit export, or payment/inventory integrations.
- Before production, test role policies with separate manager and technician accounts. Consider stricter column-level rules or server-side RPCs for technician status changes; the included policies allow assigned technicians to update their assigned job row.
- Obtain explicit technician consent and provide a clear policy before enabling location tracking.

## Build an APK in GitHub Actions (no Android Studio needed on your computer)
1. Create a private GitHub repository and upload the contents of this project folder to its `main` branch.
2. In GitHub, open **Actions** and enable workflows if prompted.
3. Select **Build JD Service Track APK** and choose **Run workflow** (or push a commit to `main`).
4. When the run finishes successfully, open the run and download the `JD-Service-Track-debug-apk` artifact. It contains `app-debug.apk`.

This workflow builds a debug APK, not a Play Store-signed release. The APK can be built before Supabase is configured, but sign-in and cloud syncing will not work until you add your Supabase URL and anon/public key in `web/config.js` and deploy/configure the backend as described above. This environment does not have the Android SDK or network access to Google's Android build packages, so it cannot compile the APK directly here.
