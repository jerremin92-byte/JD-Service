// Paste your Supabase project URL and anon/public key here.
// Never put a service_role key in this client-side file.
window.JD_CONFIG = {
  SUPABASE_URL: "https://YOUR-PROJECT.supabase.co",
  SUPABASE_ANON_KEY: "YOUR_SUPABASE_ANON_KEY"
};