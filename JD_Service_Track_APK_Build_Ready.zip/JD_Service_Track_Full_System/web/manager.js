import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
const cfg=window.JD_CONFIG||{};
const $=id=>document.getElementById(id);
const ready=cfg.SUPABASE_URL?.startsWith('https://')&&!cfg.SUPABASE_URL.includes('YOUR-PROJECT')&&cfg.SUPABASE_ANON_KEY&&!cfg.SUPABASE_ANON_KEY.includes('YOUR_');
let sb,user,profile,jobs=[],techs=[];
function msg(id,text,kind='error'){const el=$(id);el.className=kind;el.textContent=text;}
function showLogin(){ $('login').classList.remove('hidden');$('portal').classList.add('hidden');$('signOut').classList.add('hidden');}
function showPortal(){ $('login').classList.add('hidden');$('portal').classList.remove('hidden');$('signOut').classList.remove('hidden');$('welcome').textContent=`Hello, ${profile.full_name}`;$('roleLabel').textContent=profile.role==='manager'?'Manager account':'Technician account';$('tabs').classList.toggle('hidden',profile.role!=='manager');if(profile.role==='manager')loadAll();else { $('teamView').classList.add('hidden');$('jobsView').classList.remove('hidden');$('dashboardView').classList.add('hidden');loadAll();}}
async function loadAll(){
 let q=sb.from('jobs').select('*,profiles:assigned_to(full_name),job_items(*)').order('appointment_start',{ascending:true});
 if(profile.role!=='manager')q=q.eq('assigned_to',user.id);
 const {data,error}=await q;if(error){msg('loginMsg',error.message);return;}jobs=data||[];render();
 if(profile.role==='manager'){const t=await sb.from('profiles').select('id,full_name,role,active').eq('role','technician').eq('active',true).order('full_name');techs=t.data||[];renderTeam();fillAssignees();}
}
function render(){
 $('mTotal').textContent=jobs.length;$('mScheduled').textContent=jobs.filter(j=>j.status==='scheduled').length;$('mProgress').textContent=jobs.filter(j=>j.status==='in_progress').length;$('mFinished').textContent=jobs.filter(j=>j.status==='finished').length;
 const rows=jobs.map(j=>`<tr><td><b>${esc(j.order_number)} · ${esc(j.customer_name)}</b><br><span class="muted">${esc(j.service_type)}<br>${esc(j.address)}</span></td><td><span class="pill ${j.status}">${j.status.replace('_',' ')}</span></td><td>${esc(j.profiles?.full_name||'Unassigned')}</td><td>${j.appointment_start?new Date(j.appointment_start).toLocaleString():'Not set'}</td><td><button class="btn outline" data-open="${j.id}">Open</button></td></tr>`).join('');
 $('jobsTable').innerHTML=rows||'<tr><td colspan="5">No orders found.</td></tr>';
 $('recentJobs').innerHTML=jobs.slice(0,5).map(j=>`<div class="jobrow" style="padding:10px 0;border-bottom:1px solid #e2e8f0"><div><h3>${esc(j.customer_name)}</h3><span class="muted">${esc(j.order_number)} · ${esc(j.address)}</span></div><span class="pill ${j.status}">${j.status.replace('_',' ')}</span></div>`).join('')||'<p class="muted">No service orders yet.</p>';
 document.querySelectorAll('[data-open]').forEach(b=>b.onclick=()=>openJob(b.dataset.open));
}
function renderTeam(){$('teamTable').innerHTML=techs.map(t=>`<tr><td>${esc(t.full_name)}</td><td>${esc(t.id)}</td><td>${t.active?'Active':'Inactive'}</td></tr>`).join('')||'<tr><td colspan="3">No technician profiles yet.</td></tr>';}
function fillAssignees(){$('assignee').innerHTML=techs.map(t=>`<option value="${t.id}">${esc(t.full_name)}</option>`).join('');}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
async function openJob(id){const j=jobs.find(x=>x.id===id);if(!j)return;const parts=(j.job_items||[]).map(x=>`${x.name}: ${x.quantity_actual}/${x.quantity_required}`).join('\n');alert(`Order ${j.order_number}\n${j.customer_name}\n${j.address}\nStatus: ${j.status}\nChecklist:\n${parts||'No items'}`);}
$('loginForm').onsubmit=async e=>{e.preventDefault();if(!ready){msg('loginMsg','Add your Supabase project URL and anon key in web/config.js before signing in.');return;}sb=createClient(cfg.SUPABASE_URL,cfg.SUPABASE_ANON_KEY);const {data,error}=await sb.auth.signInWithPassword({email:$('email').value,password:$('password').value});if(error){msg('loginMsg',error.message);return;}user=data.user;const p=await sb.from('profiles').select('*').eq('id',user.id).single();if(p.error){await sb.auth.signOut();msg('loginMsg','Profile not found. Ask your manager to create your technician/manager profile.');return;}profile=p.data;if(!profile.active){await sb.auth.signOut();msg('loginMsg','This account is inactive. Contact your manager.');return;}showPortal();sb.channel('jd-live-jobs').on('postgres_changes',{event:'*',schema:'public',table:'jobs'},()=>loadAll()).subscribe();};
$('signOut').onclick=async()=>{await sb?.auth.signOut();showLogin();};
document.querySelectorAll('[data-view]').forEach(b=>b.onclick=()=>{document.querySelectorAll('[data-view]').forEach(x=>x.classList.toggle('active',x===b));['dashboard','jobs','team'].forEach(v=>$(`${v}View`).classList.toggle('hidden',v!==b.dataset.view));});
$('newJobBtn').onclick=()=>{$('jobFormCard').classList.remove('hidden');$('orderNo').value='JD-'+Date.now().toString().slice(-7);};
$('cancelJob').onclick=()=>{$('jobFormCard').classList.add('hidden');};
$('reload').onclick=loadAll;
$('jobForm').onsubmit=async e=>{e.preventDefault();if(!techs.length){msg('jobMsg','Add at least one active technician profile first.');return;}const payload={order_number:$('orderNo').value.trim(),customer_name:$('customer').value.trim(),phone:$('phone').value.trim()||null,service_type:$('serviceType').value.trim(),address:$('address').value.trim(),assigned_to:$('assignee').value,appointment_start:$('apptStart').value?new Date($('apptStart').value).toISOString():null,appointment_end:$('apptEnd').value?new Date($('apptEnd').value).toISOString():null,notes:$('notes').value.trim()||null,created_by:user.id};const {data,error}=await sb.from('jobs').insert(payload).select().single();if(error){msg('jobMsg',error.message);return;}const {error:itemErr}=await sb.from('job_items').insert({job_id:data.id,name:'Service call',sku:'*SERCALL',quantity_required:1});if(itemErr){msg('jobMsg','Order created, but default checklist item failed: '+itemErr.message);return;}await sb.from('job_events').insert({job_id:data.id,actor_id:user.id,event_type:'created',details:{order_number:data.order_number}});$('jobForm').reset();$('jobFormCard').classList.add('hidden');await loadAll();msg('jobMsg','Order created and assigned.','success');};
if(!ready){$('loginMsg').className='error';$('loginMsg').textContent='Setup required: configure web/config.js and run the SQL schema in your Supabase project.';}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
