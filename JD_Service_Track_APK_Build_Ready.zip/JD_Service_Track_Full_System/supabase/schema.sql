-- JD Service Track: Supabase schema and row-level security
-- Run in Supabase SQL Editor. Create the first manager in Authentication,
-- then set that user's profile role to manager using the SQL below.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  role text not null default 'technician' check (role in ('manager','technician')),
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.jobs (
  id uuid primary key default gen_random_uuid(),
  order_number text not null unique,
  customer_name text not null,
  phone text,
  address text not null,
  service_type text not null,
  appointment_start timestamptz,
  appointment_end timestamptz,
  assigned_to uuid references public.profiles(id),
  status text not null default 'scheduled'
    check (status in ('scheduled','in_progress','finished','cancelled')),
  notes text,
  started_at timestamptz,
  finished_at timestamptz,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.job_items (
  id uuid primary key default gen_random_uuid(),
  job_id uuid not null references public.jobs(id) on delete cascade,
  name text not null,
  sku text,
  quantity_required numeric(10,2) not null default 1 check (quantity_required >= 0),
  quantity_actual numeric(10,2) not null default 0 check (quantity_actual >= 0),
  is_complete boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.job_events (
  id uuid primary key default gen_random_uuid(),
  job_id uuid not null references public.jobs(id) on delete cascade,
  actor_id uuid references public.profiles(id),
  event_type text not null,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists jobs_assigned_to_idx on public.jobs(assigned_to);
create index if not exists jobs_appointment_idx on public.jobs(appointment_start);
create index if not exists job_items_job_id_idx on public.job_items(job_id);
create index if not exists job_events_job_id_idx on public.job_events(job_id);

create or replace function public.is_manager()
returns boolean language sql stable security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.role = 'manager' and p.active = true
  );
$$;

create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end;
$$;

drop trigger if exists jobs_touch_updated_at on public.jobs;
create trigger jobs_touch_updated_at before update on public.jobs
for each row execute function public.touch_updated_at();

alter table public.profiles enable row level security;
alter table public.jobs enable row level security;
alter table public.job_items enable row level security;
alter table public.job_events enable row level security;

drop policy if exists "profiles read self or manager" on public.profiles;
create policy "profiles read self or manager" on public.profiles
for select to authenticated using (id = auth.uid() or public.is_manager());

drop policy if exists "manager manage profiles" on public.profiles;
create policy "manager manage profiles" on public.profiles
for all to authenticated using (public.is_manager()) with check (public.is_manager());

drop policy if exists "manager or assigned tech read jobs" on public.jobs;
create policy "manager or assigned tech read jobs" on public.jobs
for select to authenticated using (public.is_manager() or assigned_to = auth.uid());

drop policy if exists "manager create jobs" on public.jobs;
create policy "manager create jobs" on public.jobs
for insert to authenticated with check (public.is_manager());

drop policy if exists "manager or assigned tech update jobs" on public.jobs;
create policy "manager or assigned tech update jobs" on public.jobs
for update to authenticated
using (public.is_manager() or assigned_to = auth.uid())
with check (public.is_manager() or assigned_to = auth.uid());

drop policy if exists "manager delete jobs" on public.jobs;
create policy "manager delete jobs" on public.jobs
for delete to authenticated using (public.is_manager());

drop policy if exists "manager or assigned tech read items" on public.job_items;
create policy "manager or assigned tech read items" on public.job_items
for select to authenticated using (
 public.is_manager() or exists (
   select 1 from public.jobs j where j.id = job_id and j.assigned_to = auth.uid()
 )
);

drop policy if exists "manager or assigned tech manage items" on public.job_items;
create policy "manager or assigned tech manage items" on public.job_items
for all to authenticated
using (public.is_manager() or exists (
 select 1 from public.jobs j where j.id = job_id and j.assigned_to = auth.uid()
))
with check (public.is_manager() or exists (
 select 1 from public.jobs j where j.id = job_id and j.assigned_to = auth.uid()
));

drop policy if exists "manager or assigned tech read events" on public.job_events;
create policy "manager or assigned tech read events" on public.job_events
for select to authenticated using (
 public.is_manager() or exists (
   select 1 from public.jobs j where j.id = job_id and j.assigned_to = auth.uid()
 )
);

drop policy if exists "signed-in users add own events" on public.job_events;
create policy "signed-in users add own events" on public.job_events
for insert to authenticated with check (
 actor_id = auth.uid() and (
  public.is_manager() or exists (
   select 1 from public.jobs j where j.id = job_id and j.assigned_to = auth.uid()
  )
 )
);

-- After creating the first user through Supabase Authentication, promote them:
-- update public.profiles set role = 'manager' where id = 'AUTH_USER_UUID';

-- Add tables to Supabase Realtime publication for live updates.
do $$ begin
  alter publication supabase_realtime add table public.jobs;
exception when duplicate_object then null;
when undefined_object then null;
end $$;
